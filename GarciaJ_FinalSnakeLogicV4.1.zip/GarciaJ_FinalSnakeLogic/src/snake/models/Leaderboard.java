package snake.models;

public class Leaderboard {
}
