package snake.app;

import snake.interfaces.Observer;
import snake.models.FoodPellet;
import snake.models.Leaderboard;
import snake.models.Snake;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.Random;

public class Program {
    private static Snake snake;
    private static Leaderboard leaderboard;
    private static String path = "../leaderboard.txt";
    
    public static Snake getSnake() {
        return snake;
    }
    
    public static void setSnake(Snake snake) {
        Program.snake = snake;
    }
    
    public static void createSnake(int boardSizeX, int boardSizeY) {
        Random rand = new Random();
    
        int posX = rand.nextInt(boardSizeX - 3) + 1;
        int posY = rand.nextInt(boardSizeY - 3) + 1;
        int[] position = {posX, posY};
        
        snake = new Snake(position);
    }
    
    public static void addSnakeObserver(Observer obs) {
        getSnake().attach(obs);
    }
    
    public static Leaderboard getLeaderboard() {
        return leaderboard;
    }
    
    public static void setLeaderboard(Leaderboard leaderboard) {
        Program.leaderboard = leaderboard;
    }
    
    public static String getPath() {
        return path;
    }
    
    public static void setPath(String path) {
        Program.path = path;
    }
    
}
