package snake.app;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import snake.controllers.SnakeMenuController;
import snake.models.Leaderboard;
import snake.models.LeaderboardEntry;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Driver extends Application {
	SnakeMenuController controller;
	private String path = "../leaderboardXML.xml";

	public static void main(String[] args) {
		//Program.run();
        launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../ui/snakeMenu.fxml"));
	    
        GridPane grid = loader.load();
        controller = loader.getController();
  
		Scene scene = new Scene(grid, 600, 650);
        primaryStage.setScene(scene);
        
        primaryStage.setResizable(false);
        controller.setLeaderboard(readLeaderboard());
        primaryStage.show();
        
        primaryStage.setOnCloseRequest(this::onClose);
	}
	
	private void onClose(WindowEvent event) {
        FileOutputStream out = null;
        
        Collections.sort(controller.getLeaderboard());
        
        try {
            out = new FileOutputStream(path);
            XMLEncoder encoder = new XMLEncoder(out);
            encoder.writeObject(controller.getLeaderboard());
            encoder.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<LeaderboardEntry> readLeaderboard() {
        FileInputStream in = null;
        ArrayList<LeaderboardEntry> retVal = new ArrayList<>();
        try {
            in = new FileInputStream(path);
            XMLDecoder decoder = new XMLDecoder(in);
            retVal = (ArrayList<LeaderboardEntry>) decoder.readObject();
            decoder.close();
        } catch (IOException e) {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            e.printStackTrace();
        }
        return retVal;
    }
}
