package snake.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Leaderboard implements Serializable {
    private ArrayList<LeaderboardEntry> scores;
    
    public Leaderboard() {
        scores = new ArrayList<>();
    }
    
    public ArrayList<LeaderboardEntry> getScores() {
        return scores;
    }
    
    public void setScores(ArrayList<LeaderboardEntry> scores) {
        this.scores = scores;
    }
    
    
}
