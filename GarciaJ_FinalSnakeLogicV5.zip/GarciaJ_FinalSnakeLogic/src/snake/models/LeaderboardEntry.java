package snake.models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.io.Serializable;

public class LeaderboardEntry implements Comparable<LeaderboardEntry>, Serializable {
//    private final StringProperty entryName = new SimpleStringProperty();
//    private final IntegerProperty entryScore = new SimpleIntegerProperty();
    private String entryName;
    private int entryScore;
    
    public LeaderboardEntry(String entryName, Integer entryScore) {
        setEntryName(entryName);
        setEntryScore(entryScore);
    }
    
//    public String getEntryName() {
//        return entryName.get();
//    }
//
//    public StringProperty entryNameProperty() {
//        return entryName;
//    }
//
//    public void setEntryName(String entryName) {
//        this.entryName.set(entryName);
//    }
//
//    public int getEntryScore() {
//        return entryScore.get();
//    }
//
//    public IntegerProperty entryScoreProperty() {
//        return entryScore;
//    }
//
//    public void setEntryScore(int entryScore) {
//        this.entryScore.set(entryScore);
//    }
    
    
    public String getEntryName() {
        return entryName;
    }
    
    public void setEntryName(String entryName) {
        this.entryName = entryName;
    }
    
    public int getEntryScore() {
        return entryScore;
    }
    
    public void setEntryScore(int entryScore) {
        this.entryScore = entryScore;
    }
    
    @Override
    public int compareTo(LeaderboardEntry leaderboardEntry) {
        return this.getEntryScore() - leaderboardEntry.getEntryScore();
    }
}
