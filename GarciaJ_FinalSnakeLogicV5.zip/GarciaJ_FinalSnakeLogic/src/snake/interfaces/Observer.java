package snake.interfaces;

public interface Observer {
    void update(Observable subject);
}
