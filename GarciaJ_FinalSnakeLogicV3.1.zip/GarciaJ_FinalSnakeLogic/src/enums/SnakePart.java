package enums;

public enum SnakePart {
    HEAD,
    BODY,
    TAIL;
}
