package models;

import java.util.Arrays;

public class Board {
	private char[][] boardSize;

	public char[][] getBoardSize() {
		return boardSize;
	}

	public void setBoardSize(char[][] boardSize) {
		this.boardSize = boardSize;
	}
	
	public Board() {
		
	}
	public Board(char[][] boardSize) {
		setBoardSize(boardSize);
	}

	@Override
	public String toString() {
		String board = "";
		for (char[] row : getBoardSize()) {
			board += Arrays.toString(row) + "\n";
		}
		return board;
	}
}
