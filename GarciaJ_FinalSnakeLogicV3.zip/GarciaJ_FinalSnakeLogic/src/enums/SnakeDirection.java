package enums;

public enum SnakeDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
