package interfaces;

public interface Observer {
    void update(Observable subject);
}
