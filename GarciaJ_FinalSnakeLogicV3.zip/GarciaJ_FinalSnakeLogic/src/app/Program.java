package app;

import interfaces.Observer;
import models.Snake;

import java.util.Random;

public class Program {
    private static Snake snake;
    
    public static Snake getSnake() {
        return snake;
    }
    
    public static void setSnake(Snake snake) {
        Program.snake = snake;
    }
    
    public static void createSnake(int boardSizeX, int boardSizeY) {
        Random rand = new Random();
    
        int posX = rand.nextInt(boardSizeX - 3) + 1;
        int posY = rand.nextInt(boardSizeY - 3) + 1;
        int[] position = {posX, posY};
        
        snake = new Snake(position);
    }
    
    public static void addSnakeObserver(Observer obs) {
        getSnake().attach(obs);
    }
    
}
