package app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Driver extends Application {

	public static void main(String[] args) {
		//Program.run();
        launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
        GridPane grid = FXMLLoader.load(getClass().getResource("../ui/snakeMenu.fxml"));
  
		Scene scene = new Scene(grid, 600, 650);
        primaryStage.setScene(scene);
        
        primaryStage.setResizable(false);
        primaryStage.show();
	}
}
