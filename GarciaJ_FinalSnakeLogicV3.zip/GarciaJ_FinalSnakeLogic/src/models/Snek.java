package models;

import enums.SnakeDirection;

import java.util.Random;

public class Snek {
    //	private char bodySize;
//	private char head;
//	private char tail;
    private int[] currentHeadPosition;
    private int[] currentTailPosition;
    private int[] previousTailPosition;
    private SnakeDirection direction;

//	public char getBodySize() {
//		return bodySize;
//	}
//
//	public void setBodySize(char bodySize) {
//		this.bodySize = bodySize;
//	}
//
//	public char getHead() {
//		return head;
//	}
//
//	public void setHead(char head) {
//		this.head = head;
//	}
//
//	public char getTail() {
//		return tail;
//	}
//
//	public void setTail(char tail) {
//		this.tail = tail;
//	}
    
    public int[] getCurrentHeadPosition() {
        return currentHeadPosition;
    }
    
    public void setCurrentHeadPosition(int[] currentHeadPosition) {
        this.currentHeadPosition = currentHeadPosition;
    }
    
    public int[] getCurrentTailPosition() {
        return currentTailPosition;
    }
    
    public void setCurrentTailPosition(int[] currentTailPosition) {
        this.currentTailPosition = currentTailPosition;
    }
    
    public int[] getPreviousTailPosition() {
        return previousTailPosition;
    }
    
    public void setPreviousTailPosition(int[] previousTailPosition) {
        this.previousTailPosition = previousTailPosition;
    }
    
    public SnakeDirection getDirection() {
        return direction;
    }
    
    public void setDirection(SnakeDirection direction) {
        this.direction = direction;
    }
    
    public Snek() {
    
    }
    
    public Snek(int boardWidth, int boardHeight) {
//		setBodySize(body);
//		setHead(head);
//		setTail(tail);
        Random rand = new Random();
        
        currentHeadPosition = new int[2];
        currentHeadPosition[0] = rand.nextInt(boardWidth);
        currentHeadPosition[1] = rand.nextInt(boardHeight);
        setDirection(SnakeDirection.values()[rand.nextInt(SnakeDirection.values().length)]);
        currentTailPosition = new int[2];
        previousTailPosition = new int[2];
        switch (direction) {
            case UP:
                currentTailPosition[1] = (currentHeadPosition[1] + 1);
                break;
            case DOWN:
                currentTailPosition[1] = (currentHeadPosition[1] - 1);
                break;
            case LEFT:
                currentTailPosition[1] = (currentHeadPosition[0] - 1);
                break;
            case RIGHT:
                currentTailPosition[1] = (currentHeadPosition[0] + 1);
                break;
        }
    }
    
    public void timePassed() {
        previousTailPosition = currentTailPosition;
        
    }
    
}
