package models;

public class FoodPellet {
	private int[][] position;

	public int[][] getPosition() {
		return position;
	}

	public void setPosition(int[][] position) {
		this.position = position;
	}
	public FoodPellet() {
		
	}
	public FoodPellet(int[][] position) {
		setPosition(position);
	}
}
