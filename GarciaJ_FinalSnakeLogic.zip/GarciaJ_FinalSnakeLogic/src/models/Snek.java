package models;

public class Snek {
	private char bodySize;
	private char head;
	private char tail;
	
	public char getBodySize() {
		return bodySize;
	}
	public void setBodySize(char bodySize) {
		this.bodySize = bodySize;
	}
	public char getHead() {
		return head;
	}
	public void setHead(char head) {
		this.head = head;
	}
	public char getTail() {
		return tail;
	}
	public void setTail(char tail) {
		this.tail = tail;
	}
	
	public Snek() {
		
	}
	public Snek(char body, char head, char tail) {
		setBodySize(body);
		setHead(head);
		setTail(tail);
	}
}
