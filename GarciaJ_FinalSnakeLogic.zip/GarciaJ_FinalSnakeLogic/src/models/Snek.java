package models;

public class Snek {
	private int bodySize;
	private int[][] head;
	
	public int getBodySize() {
		return bodySize;
	}
	public void setBodySize(int bodySize) {
		this.bodySize = bodySize;
	}
	public int[][] getHead() {
		return head;
	}
	public void setHead(int[][] head) {
		this.head = head;
	}
	
	private Snek() {
		
	}
	private Snek(int bodySize, int[][] head) {
		setBodySize(bodySize);
		setHead(head);
	}
}
