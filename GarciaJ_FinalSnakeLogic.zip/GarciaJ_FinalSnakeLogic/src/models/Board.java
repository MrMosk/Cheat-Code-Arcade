package models;

public class Board {
	private int[][] boardSize;

	public int[][] getBoardSize() {
		return boardSize;
	}

	public void setBoardSize(int[][] boardSize) {
		this.boardSize = boardSize;
	}
	
	public Board() {
		
	}
	public Board(int[][] boardSize) {
		setBoardSize(boardSize);
	}
}
