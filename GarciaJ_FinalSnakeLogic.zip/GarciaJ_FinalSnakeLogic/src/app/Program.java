package app;

import java.util.Random;

import models.Board;
import models.Snek;

public class Program {
	public static void run() {
		char[][] boardSize = new char[22][22];
		for (int i = 0; i < 22; i++) {
			boardSize[0][i] = 'w';
			boardSize[21][i] = 'w';
			boardSize[i][0] = 'w';
			boardSize[i][21] = 'w';
		}

		Random rng = new Random();

		char food = 'f';
		char head = 'h';
		char body = 'b';
		char tail = 't';
		boolean doesCollide = true;
		do {
			int headX = rng.nextInt(20) + 1;
			int headY = rng.nextInt(20) + 1;
			int bodyDirection = rng.nextInt(4);
			if (bodyDirection == 0) {
				boardSize[headX][headY] = head;
				if (boardSize[headX - 1][headY] == ' ') {
					boardSize[headX - 1][headY] = body;
					if (boardSize[headX - 2][headY] == ' ') {
						boardSize[headX - 2][headY] = tail;
						Snek snek = new Snek(body, head, tail);
						doesCollide = false;
					}
					else {
						boardSize[headX - 1][headY] = ' ';
						boardSize[headX][headY] = ' ';
					}
				}
				else {
					boardSize[headX][headY] = ' ';
				}
			}
			if (bodyDirection == 1) {
				boardSize[headX][headY] = head;
				if (boardSize[headX + 1][headY] == ' ') {
					boardSize[headX + 1][headY] = body;
					if (boardSize[headX + 2][headY] == ' ') {
						boardSize[headX + 2][headY] = tail;
						Snek snek = new Snek(body, head, tail);
						doesCollide = false;
					}
					else {
						boardSize[headX + 1][headY] = ' ';
						boardSize[headX][headY] = ' ';
					}
				}
				else {
					boardSize[headX][headY] = ' ';
				}
			}
			if (bodyDirection == 2) {
				boardSize[headX][headY] = head;
				if (boardSize[headX][headY - 1] == ' ') {
					boardSize[headX][headY - 1] = body;
					if (boardSize[headX][headY - 2] == ' ') {
						boardSize[headX][headY - 2] = tail;
						Snek snek = new Snek(body, head, tail);
						doesCollide = false;
					}
					else {
						boardSize[headX][headY - 1] = ' ';
						boardSize[headX][headY] = ' ';
					}
				}
				else {
					boardSize[headX][headY] = ' ';
				}
			}
			if (bodyDirection == 3) {
				boardSize[headX][headY] = head;
				if (boardSize[headX][headY + 1] == ' ') {
					boardSize[headX][headY + 1] = body;
					if (boardSize[headX][headY + 2] == ' ') {
						boardSize[headX][headY + 2] = tail;
						Snek snek = new Snek(body, head, tail);
						doesCollide = false;
					}
					else {
						boardSize[headX][headY + 1] = ' ';
						boardSize[headX][headY] = ' ';
					}
				}
				else {
					boardSize[headX][headY] = ' ';
				}
			}
		} while (doesCollide);
		boolean isFree = false;
		int x = rng.nextInt(20) + 1;
		int y = rng.nextInt(20) + 1;
		do {
			if(boardSize[x][y] != 'h' && boardSize[x][y] != 'b' && boardSize[x][y] != 't') {
				boardSize[x][y] = food;
				isFree = true;
			}
			else {
				
			}
		}while(!isFree);
		Board board = new Board(boardSize);

		System.out.println(board);
	}
}
