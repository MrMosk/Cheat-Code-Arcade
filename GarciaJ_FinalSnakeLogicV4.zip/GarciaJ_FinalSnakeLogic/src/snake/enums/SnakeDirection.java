package snake.enums;

public enum SnakeDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
