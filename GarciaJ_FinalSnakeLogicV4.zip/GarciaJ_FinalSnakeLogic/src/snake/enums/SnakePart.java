package snake.enums;

public enum SnakePart {
    HEAD,
    BODY,
    TAIL;
}
