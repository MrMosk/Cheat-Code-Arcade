package models;

public class Leaderboard {
}
