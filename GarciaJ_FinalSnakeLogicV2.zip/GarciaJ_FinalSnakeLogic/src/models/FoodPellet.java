package models;

public class FoodPellet extends Board{
	private char position;

	public char getPosition() {
		return position;
	}

	public void setPosition(char position) {
		this.position = position;
	}
	public FoodPellet() {
		
	}
	public FoodPellet(char position) {
		setPosition(position);
	}
	
	@Override
	public String toString() {
		String foodPellet = "f";
		return foodPellet;
	}
}
