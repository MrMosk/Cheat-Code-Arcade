package models;

import app.Program;

import java.util.TimerTask;

public class SnakeTimerTask extends TimerTask {
    
    @Override
    public void run() {
        Program.getSnake().move();
    }
}
