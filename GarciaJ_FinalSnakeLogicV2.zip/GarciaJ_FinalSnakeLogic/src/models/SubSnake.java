package models;

import enums.SnakeDirection;
import enums.SnakePart;
import interfaces.Observable;
import interfaces.Observer;

import java.util.ArrayList;

public class SubSnake implements Observable, Observer {
    private SnakePart snakePart;
    private int[] position;
    private ArrayList<Observer> observers;
    private SnakeDirection direction;
    private SnakeDirection previousDirection;
    
    SubSnake(SnakePart snakePart, int[] position) {
        if (position.length ==2) {
            setSnakePart(snakePart);
            setPosition(position);
        } else {
            throw new IllegalArgumentException();
        }
        observers = new ArrayList<>();
    }
    
    SubSnake(SnakePart snakePart, int[] position, SnakeDirection direction) {
        this(snakePart,position);
        setDirection(direction);
    }
    
    public SnakePart getSnakePart() {
        return snakePart;
    }
    
    public void setSnakePart(SnakePart snakePart) {
        this.snakePart = snakePart;
    }
    
    public int[] getPosition() {
        return position;
    }
    
    public void setPosition(int[] position) {
        this.position = position;
    }
    
    public int getXPosition() {
        return getPosition()[0];
    }
    
    public int getYPosition() {
        return getPosition()[1];
    }
    
    public void setXPosition(int x) {
        getPosition()[0] = x;
    }
    
    public void setYPosition(int y) {
        getPosition()[1] = y;
    }
    
    public SnakeDirection getDirection() {
        return direction;
    }
    
    public void setDirection(SnakeDirection direction) {
        this.direction = direction;
    }
    
    public ArrayList<Observer> getObservers() {
        return observers;
    }
    
    public void setObservers(ArrayList<Observer> observers) {
        this.observers = observers;
    }
    
    public SnakeDirection getPreviousDirection() {
        return previousDirection;
    }
    
    public void setPreviousDirection(SnakeDirection previousDirection) {
        this.previousDirection = previousDirection;
    }
    
    public int getPreviousXPosition() {
        int retVal = 0;
        switch (getPreviousDirection()) {
            case UP:
                retVal = getXPosition() + 1;
                break;
            case DOWN:
                retVal = getXPosition() - 1;
                break;
            case LEFT:
                retVal = getXPosition();
                break;
            case RIGHT:
                retVal = getXPosition();
                break;
        }
        return retVal;
    }
    
    public int getPreviousYPosition() {
        int retVal = 0;
        switch (getPreviousDirection()) {
            case UP:
                retVal = getXPosition();
                break;
            case DOWN:
                retVal = getXPosition();
                break;
            case LEFT:
                retVal = getXPosition() + 1;
                break;
            case RIGHT:
                retVal = getXPosition() - 1;
                break;
        }
        return retVal;
    }
    
    @Override
    public void attach(Observer obs) {
        observers.add(obs);
    }
    
    @Override
    public void dettach(Observer obs) {
        observers.remove(obs);
    }
    
    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
    
    @Override
    public void update(Observable subSnake) {
        setPreviousDirection(getDirection());
        setDirection(((SubSnake) subSnake).getPreviousDirection());
        switch (getDirection()) {
            case UP:
                setYPosition(getYPosition() + 1);
                break;
            case DOWN:
                setYPosition(getYPosition() - 1);
                break;
            case LEFT:
                setXPosition(getXPosition() - 1);
                break;
            case RIGHT:
                setXPosition(getXPosition() + 1);
                break;
        }
        notifyObservers();
    }
}
