package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SnakeMenuController implements Initializable {
    
    @FXML
    private Button playButtonSnake;
    
    @FXML
    private Button leaderboardButtonSnake;
    
    @FXML
    private Button exitButtonSnake;
    
    @FXML
    void exitButtonClickedSnake(ActionEvent event) {
    
    }
    
    @FXML
    void leaderboardButtonClickedSnake(ActionEvent event) {
    
    }
    
    @FXML
    void playButtonClickedSnake(ActionEvent event) {
        Stage stage = (Stage) playButtonSnake.getScene().getWindow();
        try {
            GridPane grid = FXMLLoader.load(getClass().getResource("../ui/snakeGame.fxml"));
            stage.setScene(new Scene(grid, 600, 650));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    
    }
    
}
