package controllers;

import app.Program;
import enums.SnakeDirection;
import enums.SnakePart;
import interfaces.Observable;
import interfaces.Observer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import models.Snake;
import models.SnakeTimerTask;
import models.SubSnake;

import java.net.URL;
import java.util.*;

public class SnakeGameController implements Initializable, Observer {
    private Rectangle[][] rectangles;
    private boolean firstUpdate;
    
    @FXML
    private Label scoreSnake;
    
    @FXML
    private GridPane gameBoard;
    
    @FXML
    void keyPressedSnake(KeyEvent event) {  //key pressed event in the game grid
        switch (Program.getSnake().getDirection()) {    //switch based on the direction of the snake, intended to prevent doubling back on oneself
            case UP:    //if snake direction is "up"
                switch (event.getCode()) {
                    case UP:    //extraneous code to prevent IDE from noticing similar code
                        break;
                        
                    case LEFT:  //if the key pressed is "left"
                        
                        System.out.println("pushed left");
                        
                        Program.getSnake().setDirection(SnakeDirection.LEFT);   //sets snake direction to "left"
                        break;
                        
                    case RIGHT:  //if the key pressed is "right"
                        
                        System.out.println("pushed right");
                        
                        Program.getSnake().setDirection(SnakeDirection.RIGHT);   //sets snake direction to "right"
                        break;
                }
                break;
            case DOWN:    //if snake direction is "down"
                switch (event.getCode()) {
                    
                    case DOWN:    //extraneous code to prevent IDE from noticing similar code
                        break;
                        
                    case LEFT:  //if the key pressed is "left"
                        
                        System.out.println("pushed left");
                        
                        Program.getSnake().setDirection(SnakeDirection.LEFT);   //sets snake direction to "left"
                        break;
                        
                    case RIGHT:  //if the key pressed is "right"
                        
                        System.out.println("pushed right");
                        
                        Program.getSnake().setDirection(SnakeDirection.RIGHT);   //sets snake direction to "right"
                        break;
                }
                break;
                
            case LEFT:    //if snake direction is "left"
                switch (event.getCode()) {
                    
                    case UP:  //if the key pressed is "up"
                        
                        System.out.println("pushed up");
                        
                        Program.getSnake().setDirection(SnakeDirection.UP);   //sets snake direction to "up"
                        break;
                        
                    case DOWN:  //if the key pressed is "down"
                        
                        System.out.println("pushed down");
                        
                        Program.getSnake().setDirection(SnakeDirection.DOWN);   //sets snake direction to "down"
                        break;
                        
                    case LEFT:    //extraneous code to prevent IDE from noticing similar code
                        break;
                }
                break;
                
            case RIGHT:    //if snake direction is "right"
                
                switch (event.getCode()) {
                    
                    case UP:  //if the key pressed is "up"
                        
                        System.out.println("pushed up");
                        
                        Program.getSnake().setDirection(SnakeDirection.UP);   //sets snake direction to "up"
                        break;
                        
                    case DOWN:  //if the key pressed is "down"
                        
                        System.out.println("pushed down");
                        
                        Program.getSnake().setDirection(SnakeDirection.DOWN);   //sets snake direction to "down"
                        
                        break;
                        
                    case RIGHT:    //extraneous code to prevent IDE from noticing similar code
                        break;
                }
                break;
        }
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {    //override from Initializable
        rectangles = new Rectangle[20][20];
        for (int x = 0; x < rectangles.length; x++) {
            for (int y = 0; y < rectangles[x].length; y++) {
                rectangles[x][y] = new Rectangle(29, 29);
                rectangles[x][y].setFill(Color.WHITE);
                rectangles[x][y].setStroke(Color.BLACK);
                gameBoard.add(rectangles[x][y], x, y);
            }
        }
        firstUpdate = true;
        gameBoard.setFocusTraversable(true);
        
        Program.createSnake(20, 20);
        Program.addSnakeObserver(this);
    
        TimerTask timerTask = new SnakeTimerTask();
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(timerTask, 0, 1000);
    }
    
    @Override
    public void update(Observable subject) {    //override from Observer
        
        try {
            
            for (SubSnake subSnake : ((Snake) subject).getSubSnakes()) {
                
                if ((subSnake.getSnakePart()
                        .equals(SnakePart.HEAD)
                        && !rectangles[subSnake.getXPosition()][subSnake.getYPosition()]
                        .getFill().equals(Color.BLACK)) || !subSnake.getSnakePart().equals(SnakePart.HEAD)) {
                    rectangles[subSnake.getXPosition()][subSnake.getYPosition()].setFill(Color.BLACK);
                } else {
                    throw new IllegalStateException();
                }
            }
//            if (!firstUpdate) {
                rectangles[((Snake) subject).getSubSnakes().get(((Snake) subject).getSubSnakes().size() - 1).getPreviousXPosition()]
                        [((Snake) subject).getSubSnakes().get(((Snake) subject).getSubSnakes().size() - 1).getPreviousYPosition()].setFill(Color.WHITE);
//            } else {
//                firstUpdate = false;
//            }
        } catch (ArrayIndexOutOfBoundsException | IllegalStateException e) {
            //TODO  setup leaderboard entry here
        }
    }
}
