package app;

import interfaces.Observer;
import models.Snake;

import java.util.Random;

public class Program {
    private static Snake snake;
    
    public static Snake getSnake() {
        return snake;
    }
    
    public static void setSnake(Snake snake) {
        Program.snake = snake;
    }
    
    public static void createSnake(int boardSizeX, int boardSizeY) {
        Random rand = new Random();
    
        int posX = rand.nextInt(boardSizeX - 3) + 1;
        int posY = rand.nextInt(boardSizeY - 3) + 1;
        int[] position = {posX, posY};
        
        snake = new Snake(position);
    }
    
    public static void addSnakeObserver(Observer obs) {
        getSnake().attach(obs);
    }
    
    //    public static void run() {
//		char[][] boardSize = new char[22][22];
//		for (int i = 0; i < 22; i++) {
//			boardSize[0][i] = 'w';
//			boardSize[21][i] = 'w';
//			boardSize[i][0] = 'w';
//			boardSize[i][21] = 'w';
//		}
//
//		Random rng = new Random();
//
//		char food = 'f';
//		char head = 'h';
//		char body = 'b';
//		char tail = 't';
//		boolean doesCollide = true;
//		do {
//			int headX = rng.nextInt(20) + 1;
//			int headY = rng.nextInt(20) + 1;
//			int bodyDirection = rng.nextInt(4);
//			if (bodyDirection == 0) {
//				boardSize[headX][headY] = head;
//				if (boardSize[headX - 1][headY] == ' ') {
//					boardSize[headX - 1][headY] = body;
//					if (boardSize[headX - 2][headY] == ' ') {
//						boardSize[headX - 2][headY] = tail;
//						Snek snek = new Snek(body, head, tail);
//						doesCollide = false;
//					}
//					else {
//						boardSize[headX - 1][headY] = ' ';
//						boardSize[headX][headY] = ' ';
//					}
//				}
//				else {
//					boardSize[headX][headY] = ' ';
//				}
//			}
//			if (bodyDirection == 1) {
//				boardSize[headX][headY] = head;
//				if (boardSize[headX + 1][headY] == ' ') {
//					boardSize[headX + 1][headY] = body;
//					if (boardSize[headX + 2][headY] == ' ') {
//						boardSize[headX + 2][headY] = tail;
//						Snek snek = new Snek(body, head, tail);
//						doesCollide = false;
//					}
//					else {
//						boardSize[headX + 1][headY] = ' ';
//						boardSize[headX][headY] = ' ';
//					}
//				}
//				else {
//					boardSize[headX][headY] = ' ';
//				}
//			}
//			if (bodyDirection == 2) {
//				boardSize[headX][headY] = head;
//				if (boardSize[headX][headY - 1] == ' ') {
//					boardSize[headX][headY - 1] = body;
//					if (boardSize[headX][headY - 2] == ' ') {
//						boardSize[headX][headY - 2] = tail;
//						Snek snek = new Snek(body, head, tail);
//						doesCollide = false;
//					}
//					else {
//						boardSize[headX][headY - 1] = ' ';
//						boardSize[headX][headY] = ' ';
//					}
//				}
//				else {
//					boardSize[headX][headY] = ' ';
//				}
//			}
//			if (bodyDirection == 3) {
//				boardSize[headX][headY] = head;
//				if (boardSize[headX][headY + 1] == ' ') {
//					boardSize[headX][headY + 1] = body;
//					if (boardSize[headX][headY + 2] == ' ') {
//						boardSize[headX][headY + 2] = tail;
//						Snek snek = new Snek(body, head, tail);
//						doesCollide = false;
//					}
//					else {
//						boardSize[headX][headY + 1] = ' ';
//						boardSize[headX][headY] = ' ';
//					}
//				}
//				else {
//					boardSize[headX][headY] = ' ';
//				}
//			}
//		} while (doesCollide);
//		boolean isFree = false;
//		int x = rng.nextInt(20) + 1;
//		int y = rng.nextInt(20) + 1;
//		do {
//			if(boardSize[x][y] != 'h' && boardSize[x][y] != 'b' && boardSize[x][y] != 't') {
//				boardSize[x][y] = food;
//				isFree = true;
//			}
//			else {
//
//			}
//		}while(!isFree);
//		Board board = new Board(boardSize);
//
//		System.out.println(board);
  
//		Random rand = new Random();
//
//		int boardSizeX = 20;
//		int boardSizeY = 20;
//
//		int posX = rand.nextInt(boardSizeX - 2) + 1;
//		int posY = rand.nextInt(boardSizeY - 2) + 1;
//		int[] position = {posX, posY};
//
//        Snake snake = new Snake(position);
//        setSnake(snake);
        
//        try {
//            timer.run();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//    }
}
